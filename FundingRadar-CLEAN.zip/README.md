# FundingRadar
Telegram bot for crypto funding rates
