import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")
ADMIN_USER_ID = 1055454475  # ← kendi Telegram user ID’ni buraya yaz
